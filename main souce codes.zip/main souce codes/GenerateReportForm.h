#pragma once

namespace FinalProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for GenerateReportForm
	/// </summary>
	public ref class GenerateReportForm : public System::Windows::Forms::Form
	{
	private:
		// MySQL-related variables
		MySqlConnection^ sqlConn;
		MySqlCommand^ sqlCmd;
		String^ connectionString;

	public:
		GenerateReportForm(void)
		{
			InitializeComponent();
		}

	protected:
		~GenerateReportForm()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->buttonStudentProgress = (gcnew System::Windows::Forms::Button());
			this->buttonCourseCompletion = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// buttonStudentProgress
			// 
			this->buttonStudentProgress->Location = System::Drawing::Point(50, 50);
			this->buttonStudentProgress->Name = L"buttonStudentProgress";
			this->buttonStudentProgress->Size = System::Drawing::Size(150, 30);
			this->buttonStudentProgress->TabIndex = 0;
			this->buttonStudentProgress->Text = L"Student Progress Report";
			this->buttonStudentProgress->UseVisualStyleBackColor = true;
			this->buttonStudentProgress->Click += gcnew System::EventHandler(this, &GenerateReportForm::buttonStudentProgress_Click);
			// 
			// buttonCourseCompletion
			// 
			this->buttonCourseCompletion->Location = System::Drawing::Point(50, 100);
			this->buttonCourseCompletion->Name = L"buttonCourseCompletion";
			this->buttonCourseCompletion->Size = System::Drawing::Size(150, 30);
			this->buttonCourseCompletion->TabIndex = 1;
			this->buttonCourseCompletion->Text = L"Course Completion Report";
			this->buttonCourseCompletion->UseVisualStyleBackColor = true;
			this->buttonCourseCompletion->Click += gcnew System::EventHandler(this, &GenerateReportForm::buttonCourseCompletion_Click);
			// 
			// GenerateReportForm
			// 
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->buttonCourseCompletion);
			this->Controls->Add(this->buttonStudentProgress);
			this->Name = L"GenerateReportForm";
			this->Text = L"Generate Report";
			this->ResumeLayout(false);

		}
#pragma endregion

		// Button 1 Click Event (Student Progress Report)
	private: System::Void buttonStudentProgress_Click(System::Object^ sender, System::EventArgs^ e) {
		MessageBox::Show("Generating Student Progress Report...");
	}

		   // Button 2 Click Event (Course Completion Report)
	private: System::Void buttonCourseCompletion_Click(System::Object^ sender, System::EventArgs^ e) {
		MessageBox::Show("Generating Course Completion Report...");
	}

		   // Private button members
	private: System::Windows::Forms::Button^ buttonStudentProgress;
	private: System::Windows::Forms::Button^ buttonCourseCompletion;
	};
}
