#include "LoginForm.h"

using namespace System;
using namespace System::Windows::Forms;
int main(array<String^>^ args){

Application::EnableVisualStyles();
Application::SetCompatibleTextRenderingDefault(false);
FinalProject::LoginForm form;
Application::Run(% form);

}