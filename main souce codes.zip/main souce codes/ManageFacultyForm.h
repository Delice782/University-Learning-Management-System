#pragma once

namespace FinalProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace MySql::Data::MySqlClient;

    public ref class ManageFacultyForm : public System::Windows::Forms::Form
    {
    private:
        MySqlConnection^ sqlConn;
        MySqlCommand^ sqlCmd;
        MySqlDataAdapter^ sqlAdapter;
        DataTable^ facultyTable;
        String^ connectionString;

    public:
        ManageFacultyForm(void)
        {
            InitializeComponent();

            // Initialize MySQL components
            sqlConn = gcnew MySqlConnection();
            sqlCmd = gcnew MySqlCommand();
            sqlAdapter = gcnew MySqlDataAdapter();
            facultyTable = gcnew DataTable();
            connectionString = "server=localhost;user id=root;password=;database=lms;";
            sqlConn->ConnectionString = connectionString;

            LoadFacultyData();
        }

    protected:
        ~ManageFacultyForm()
        {
            if (components)
            {
                delete components;
            }
        }

    private: System::Windows::Forms::DataGridView^ dataGridView1;
    private: System::Windows::Forms::Button^ btnAdd;
    private: System::Windows::Forms::Button^ btnEdit;
    private: System::Windows::Forms::Button^ btnDelete;
    private: System::Windows::Forms::TextBox^ txtFacultyID;
    private: System::Windows::Forms::TextBox^ txtUserID;
    private: System::Windows::Forms::TextBox^ txtDateOfAppointment;
    private: System::Windows::Forms::TextBox^ txtDepartment;
    private: System::Windows::Forms::Label^ label1;
    private: System::Windows::Forms::Label^ label2;
    private: System::Windows::Forms::Label^ label3;
    private: System::Windows::Forms::Label^ label4;

    private:
        System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
        void InitializeComponent(void)
        {
            this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
            this->btnAdd = (gcnew System::Windows::Forms::Button());
            this->btnEdit = (gcnew System::Windows::Forms::Button());
            this->btnDelete = (gcnew System::Windows::Forms::Button());
            this->txtFacultyID = (gcnew System::Windows::Forms::TextBox());
            this->txtUserID = (gcnew System::Windows::Forms::TextBox());
            this->txtDateOfAppointment = (gcnew System::Windows::Forms::TextBox());
            this->txtDepartment = (gcnew System::Windows::Forms::TextBox());
            this->label1 = (gcnew System::Windows::Forms::Label());
            this->label2 = (gcnew System::Windows::Forms::Label());
            this->label3 = (gcnew System::Windows::Forms::Label());
            this->label4 = (gcnew System::Windows::Forms::Label());
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
            this->SuspendLayout();
            // 
            // dataGridView1
            // 
            this->dataGridView1->Location = System::Drawing::Point(30, 160);
            this->dataGridView1->Name = L"dataGridView1";
            this->dataGridView1->Size = System::Drawing::Size(500, 200);
            this->dataGridView1->TabIndex = 0;
            this->dataGridView1->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &ManageFacultyForm::dataGridView1_CellContentClick);
            // 
            // btnAdd
            // 
            this->btnAdd->Location = System::Drawing::Point(30, 120);
            this->btnAdd->Name = L"btnAdd";
            this->btnAdd->Size = System::Drawing::Size(75, 23);
            this->btnAdd->TabIndex = 1;
            this->btnAdd->Text = L"Add";
            this->btnAdd->UseVisualStyleBackColor = true;
            this->btnAdd->Click += gcnew System::EventHandler(this, &ManageFacultyForm::btnAdd_Click);
            // 
            // btnEdit
            // 
            this->btnEdit->Location = System::Drawing::Point(120, 120);
            this->btnEdit->Name = L"btnEdit";
            this->btnEdit->Size = System::Drawing::Size(75, 23);
            this->btnEdit->TabIndex = 2;
            this->btnEdit->Text = L"Edit";
            this->btnEdit->UseVisualStyleBackColor = true;
            this->btnEdit->Click += gcnew System::EventHandler(this, &ManageFacultyForm::btnEdit_Click);
            // 
            // btnDelete
            // 
            this->btnDelete->Location = System::Drawing::Point(210, 120);
            this->btnDelete->Name = L"btnDelete";
            this->btnDelete->Size = System::Drawing::Size(75, 23);
            this->btnDelete->TabIndex = 3;
            this->btnDelete->Text = L"Delete";
            this->btnDelete->UseVisualStyleBackColor = true;
            this->btnDelete->Click += gcnew System::EventHandler(this, &ManageFacultyForm::btnDelete_Click);
            // 
            // txtFacultyID
            // 
            this->txtFacultyID->Location = System::Drawing::Point(120, 20);
            this->txtFacultyID->Name = L"txtFacultyID";
            this->txtFacultyID->Size = System::Drawing::Size(100, 20);
            this->txtFacultyID->TabIndex = 4;
            // 
            // txtUserID
            // 
            this->txtUserID->Location = System::Drawing::Point(120, 40);
            this->txtUserID->Name = L"txtUserID";
            this->txtUserID->Size = System::Drawing::Size(100, 20);
            this->txtUserID->TabIndex = 5;
            // 
            // txtDateOfAppointment
            // 
            this->txtDateOfAppointment->Location = System::Drawing::Point(120, 60);
            this->txtDateOfAppointment->Name = L"txtDateOfAppointment";
            this->txtDateOfAppointment->Size = System::Drawing::Size(100, 20);
            this->txtDateOfAppointment->TabIndex = 6;
            // 
            // txtDepartment
            // 
            this->txtDepartment->Location = System::Drawing::Point(120, 80);
            this->txtDepartment->Name = L"txtDepartment";
            this->txtDepartment->Size = System::Drawing::Size(100, 20);
            this->txtDepartment->TabIndex = 7;
            // 
            // label1
            // 
            this->label1->Location = System::Drawing::Point(30, 20);
            this->label1->Name = L"label1";
            this->label1->Size = System::Drawing::Size(100, 23);
            this->label1->TabIndex = 8;
            this->label1->Text = L"Faculty ID:";
            // 
            // label2
            // 
            this->label2->Location = System::Drawing::Point(30, 40);
            this->label2->Name = L"label2";
            this->label2->Size = System::Drawing::Size(100, 23);
            this->label2->TabIndex = 9;
            this->label2->Text = L"User ID:";
            // 
            // label3
            // 
            this->label3->Location = System::Drawing::Point(30, 60);
            this->label3->Name = L"label3";
            this->label3->Size = System::Drawing::Size(100, 23);
            this->label3->TabIndex = 10;
            this->label3->Text = L"Date of Appointment:";
            // 
            // label4
            // 
            this->label4->Location = System::Drawing::Point(30, 80);
            this->label4->Name = L"label4";
            this->label4->Size = System::Drawing::Size(100, 23);
            this->label4->TabIndex = 11;
            this->label4->Text = L"Department:";
            // 
            // ManageFacultyForm
            // 
            this->ClientSize = System::Drawing::Size(600, 400);
            this->Controls->Add(this->dataGridView1);
            this->Controls->Add(this->btnAdd);
            this->Controls->Add(this->btnEdit);
            this->Controls->Add(this->btnDelete);
            this->Controls->Add(this->txtFacultyID);
            this->Controls->Add(this->txtUserID);
            this->Controls->Add(this->txtDateOfAppointment);
            this->Controls->Add(this->txtDepartment);
            this->Controls->Add(this->label1);
            this->Controls->Add(this->label2);
            this->Controls->Add(this->label3);
            this->Controls->Add(this->label4);
            this->Name = L"ManageFacultyForm";
            this->Text = L"ManageFacultyForm";
            this->Load += gcnew System::EventHandler(this, &ManageFacultyForm::ManageFacultyForm_Load);
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
            this->ResumeLayout(false);
            this->PerformLayout();

        }
#pragma endregion

    private:
        void LoadFacultyData()
        {
            try
            {
                sqlConn->Open();
                String^ query = "SELECT * FROM faculty";
                sqlCmd->CommandText = query;
                sqlCmd->Connection = sqlConn;

                sqlAdapter->SelectCommand = sqlCmd;
                facultyTable->Clear();
                sqlAdapter->Fill(facultyTable);
                dataGridView1->DataSource = facultyTable;
            }
            catch (Exception^ ex)
            {
                MessageBox::Show("Failed to load faculty data: " + ex->Message);
            }
            finally
            {
                sqlConn->Close();
            }
        }

        void btnAdd_Click(System::Object^ sender, System::EventArgs^ e)
        {
            try
            {
                sqlConn->Open();
                String^ query = "INSERT INTO faculty(facultyID, userID, date_of_appointment, department) VALUES (@facultyID, @userID, @dateOfAppointment, @department)";
                sqlCmd->CommandText = query;
                sqlCmd->Connection = sqlConn;
                sqlCmd->Parameters->AddWithValue("@facultyID", txtFacultyID->Text);
                sqlCmd->Parameters->AddWithValue("@userID", txtUserID->Text);
                sqlCmd->Parameters->AddWithValue("@dateOfAppointment", txtDateOfAppointment->Text);
                sqlCmd->Parameters->AddWithValue("@department", txtDepartment->Text);

                sqlCmd->ExecuteNonQuery();
                MessageBox::Show("Faculty added successfully!");
                LoadFacultyData();
            }
            catch (Exception^ ex)
            {
                MessageBox::Show("Failed to add faculty: " + ex->Message);
            }
            finally
            {
                sqlCmd->Parameters->Clear();
                sqlConn->Close();
            }
        }

        void btnEdit_Click(System::Object^ sender, System::EventArgs^ e)
        {
            try
            {
                if (dataGridView1->SelectedRows->Count > 0)
                {
                    DataGridViewRow^ selectedRow = dataGridView1->SelectedRows[0];
                    String^ id = selectedRow->Cells["facultyID"]->Value->ToString();

                    sqlConn->Open();
                    String^ query = "UPDATE faculty SET facultyID=@facultyID, userID=@userID, date_of_appointment=@dateOfAppointment, department=@department WHERE facultyID=@id";
                    sqlCmd->CommandText = query;
                    sqlCmd->Connection = sqlConn;
                    sqlCmd->Parameters->AddWithValue("@facultyID", txtFacultyID->Text);
                    sqlCmd->Parameters->AddWithValue("@userID", txtUserID->Text);
                    sqlCmd->Parameters->AddWithValue("@dateOfAppointment", txtDateOfAppointment->Text);
                    sqlCmd->Parameters->AddWithValue("@department", txtDepartment->Text);
                    sqlCmd->Parameters->AddWithValue("@id", id);

                    sqlCmd->ExecuteNonQuery();
                    MessageBox::Show("Faculty updated successfully!");
                    LoadFacultyData();
                }
                else
                {
                    MessageBox::Show("Please select a row to edit.");
                }
            }
            catch (Exception^ ex)
            {
                MessageBox::Show("Failed to edit faculty: " + ex->Message);
            }
            finally
            {
                sqlCmd->Parameters->Clear();
                sqlConn->Close();
            }
        }

        void btnDelete_Click(System::Object^ sender, System::EventArgs^ e)
        {
            try
            {
                if (dataGridView1->SelectedRows->Count > 0)
                {
                    DataGridViewRow^ selectedRow = dataGridView1->SelectedRows[0];
                    String^ id = selectedRow->Cells["facultyID"]->Value->ToString();

                    sqlConn->Open();
                    String^ query = "DELETE FROM faculty WHERE facultyID=@id";
                    sqlCmd->CommandText = query;
                    sqlCmd->Connection = sqlConn;
                    sqlCmd->Parameters->AddWithValue("@id", id);

                    sqlCmd->ExecuteNonQuery();
                    MessageBox::Show("Faculty deleted successfully!");
                    LoadFacultyData();
                }
                else
                {
                    MessageBox::Show("Please select a row to delete.");
                }
            }
            catch (Exception^ ex)
            {
                MessageBox::Show("Failed to delete faculty: " + ex->Message);
            }
            finally
            {
                sqlCmd->Parameters->Clear();
                sqlConn->Close();
            }
        }
    private: System::Void dataGridView1_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
    }
private: System::Void ManageFacultyForm_Load(System::Object^ sender, System::EventArgs^ e) {
}
};
}