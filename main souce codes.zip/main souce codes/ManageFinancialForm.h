#pragma once

namespace FinalProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for ManageFinancialForm
	/// </summary>
	public ref class ManageFinancialForm : public System::Windows::Forms::Form
	{
	private:
		// MySQL-related variables
		MySqlConnection^ sqlConn;
		MySqlCommand^ sqlCmd;
		String^ connectionString;

	public:
		ManageFinancialForm(void)
		{
			InitializeComponent();
		}

	protected:
		~ManageFinancialForm()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		System::ComponentModel::Container^ components;
		System::Windows::Forms::DataGridView^ dataGridViewFinancials;
		System::Windows::Forms::Button^ buttonAdd;
		System::Windows::Forms::Button^ buttonEdit;
		System::Windows::Forms::Button^ buttonDelete;

#pragma region Windows Form Designer generated code
		void InitializeComponent(void)
		{
			this->dataGridViewFinancials = (gcnew System::Windows::Forms::DataGridView());
			this->buttonAdd = (gcnew System::Windows::Forms::Button());
			this->buttonEdit = (gcnew System::Windows::Forms::Button());
			this->buttonDelete = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridViewFinancials))->BeginInit();
			this->SuspendLayout();
			// 
			// dataGridViewFinancials
			// 
			this->dataGridViewFinancials->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridViewFinancials->Location = System::Drawing::Point(482, 201);
			this->dataGridViewFinancials->Name = L"dataGridViewFinancials";
			this->dataGridViewFinancials->Size = System::Drawing::Size(400, 200);
			this->dataGridViewFinancials->TabIndex = 0;
			// 
			// buttonAdd
			// 
			this->buttonAdd->Location = System::Drawing::Point(482, 421);
			this->buttonAdd->Name = L"buttonAdd";
			this->buttonAdd->Size = System::Drawing::Size(75, 23);
			this->buttonAdd->TabIndex = 1;
			this->buttonAdd->Text = L"Add Record";
			this->buttonAdd->UseVisualStyleBackColor = true;
			this->buttonAdd->Click += gcnew System::EventHandler(this, &ManageFinancialForm::buttonAdd_Click);
			// 
			// buttonEdit
			// 
			this->buttonEdit->Location = System::Drawing::Point(582, 421);
			this->buttonEdit->Name = L"buttonEdit";
			this->buttonEdit->Size = System::Drawing::Size(75, 23);
			this->buttonEdit->TabIndex = 2;
			this->buttonEdit->Text = L"Edit Record";
			this->buttonEdit->UseVisualStyleBackColor = true;
			this->buttonEdit->Click += gcnew System::EventHandler(this, &ManageFinancialForm::buttonEdit_Click);
			// 
			// buttonDelete
			// 
			this->buttonDelete->Location = System::Drawing::Point(682, 421);
			this->buttonDelete->Name = L"buttonDelete";
			this->buttonDelete->Size = System::Drawing::Size(75, 23);
			this->buttonDelete->TabIndex = 3;
			this->buttonDelete->Text = L"Delete Record";
			this->buttonDelete->UseVisualStyleBackColor = true;
			this->buttonDelete->Click += gcnew System::EventHandler(this, &ManageFinancialForm::buttonDelete_Click);
			// 
			// ManageFinancialForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(974, 649);
			this->Controls->Add(this->buttonDelete);
			this->Controls->Add(this->buttonEdit);
			this->Controls->Add(this->buttonAdd);
			this->Controls->Add(this->dataGridViewFinancials);
			this->Name = L"ManageFinancialForm";
			this->Text = L"Manage Financial Records";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridViewFinancials))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion

	private: System::Void buttonAdd_Click(System::Object^ sender, System::EventArgs^ e) {
		// Implement functionality to add a financial record
		MessageBox::Show("Add functionality is not yet implemented.");
	}

	private: System::Void buttonEdit_Click(System::Object^ sender, System::EventArgs^ e) {
		// Implement functionality to edit an existing financial record
		MessageBox::Show("Edit functionality is not yet implemented.");
	}

	private: System::Void buttonDelete_Click(System::Object^ sender, System::EventArgs^ e) {
		// Implement functionality to delete a financial record
		MessageBox::Show("Delete functionality is not yet implemented.");
	}
	};
}
