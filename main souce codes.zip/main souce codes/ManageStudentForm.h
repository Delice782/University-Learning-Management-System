#pragma once

namespace FinalProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace MySql::Data::MySqlClient;

    public ref class ManageStudentForm : public System::Windows::Forms::Form
    {
    private:
        MySqlConnection^ sqlConn;
        MySqlCommand^ sqlCmd;
        MySqlDataAdapter^ sqlAdapter;
        DataTable^ studentTable;
        String^ connectionString;

    public:
        ManageStudentForm(void)
        {
            InitializeComponent();

            // Initialize MySQL components
            sqlConn = gcnew MySqlConnection();
            sqlCmd = gcnew MySqlCommand();
            sqlAdapter = gcnew MySqlDataAdapter();
            studentTable = gcnew DataTable();
            connectionString = "server=localhost;user id=root;password=;database=lms;";
            sqlConn->ConnectionString = connectionString;

            LoadStudentData();
        }

    protected:
        ~ManageStudentForm()
        {
            if (components)
            {
                delete components;
            }
        }

    private: System::Windows::Forms::DataGridView^ dataGridView1;
    private: System::Windows::Forms::Button^ btnAdd;
    private: System::Windows::Forms::Button^ btnEdit;
    private: System::Windows::Forms::Button^ btnDelete;
    private: System::Windows::Forms::TextBox^ txtStudentID;
    private: System::Windows::Forms::TextBox^ txtUserID;
    private: System::Windows::Forms::TextBox^ txtDateOfEnrollment;
    private: System::Windows::Forms::TextBox^ txtCourse;
    private: System::Windows::Forms::Label^ label1;
    private: System::Windows::Forms::Label^ label2;
    private: System::Windows::Forms::Label^ label3;
    private: System::Windows::Forms::Label^ label4;

    private:
        System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
        void InitializeComponent(void)
        {
            this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
            this->btnAdd = (gcnew System::Windows::Forms::Button());
            this->btnEdit = (gcnew System::Windows::Forms::Button());
            this->btnDelete = (gcnew System::Windows::Forms::Button());
            this->txtStudentID = (gcnew System::Windows::Forms::TextBox());
            this->txtUserID = (gcnew System::Windows::Forms::TextBox());
            this->txtDateOfEnrollment = (gcnew System::Windows::Forms::TextBox());
            this->txtCourse = (gcnew System::Windows::Forms::TextBox());
            this->label1 = (gcnew System::Windows::Forms::Label());
            this->label2 = (gcnew System::Windows::Forms::Label());
            this->label3 = (gcnew System::Windows::Forms::Label());
            this->label4 = (gcnew System::Windows::Forms::Label());
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
            this->SuspendLayout();
            // 
            // dataGridView1
            // 
            this->dataGridView1->Location = System::Drawing::Point(452, 297);
            this->dataGridView1->Name = L"dataGridView1";
            this->dataGridView1->Size = System::Drawing::Size(500, 200);
            this->dataGridView1->TabIndex = 0;
            this->dataGridView1->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &ManageStudentForm::dataGridView1_CellContentClick);
            // 
            // btnAdd
            // 
            this->btnAdd->Location = System::Drawing::Point(452, 257);
            this->btnAdd->Name = L"btnAdd";
            this->btnAdd->Size = System::Drawing::Size(75, 23);
            this->btnAdd->TabIndex = 1;
            this->btnAdd->Text = L"Add";
            this->btnAdd->UseVisualStyleBackColor = true;
            this->btnAdd->Click += gcnew System::EventHandler(this, &ManageStudentForm::btnAdd_Click);
            // 
            // btnEdit
            // 
            this->btnEdit->Location = System::Drawing::Point(542, 257);
            this->btnEdit->Name = L"btnEdit";
            this->btnEdit->Size = System::Drawing::Size(75, 23);
            this->btnEdit->TabIndex = 2;
            this->btnEdit->Text = L"Edit";
            this->btnEdit->UseVisualStyleBackColor = true;
            this->btnEdit->Click += gcnew System::EventHandler(this, &ManageStudentForm::btnEdit_Click);
            // 
            // btnDelete
            // 
            this->btnDelete->Location = System::Drawing::Point(632, 257);
            this->btnDelete->Name = L"btnDelete";
            this->btnDelete->Size = System::Drawing::Size(75, 23);
            this->btnDelete->TabIndex = 3;
            this->btnDelete->Text = L"Delete";
            this->btnDelete->UseVisualStyleBackColor = true;
            this->btnDelete->Click += gcnew System::EventHandler(this, &ManageStudentForm::btnDelete_Click);
            // 
            // txtStudentID
            // 
            this->txtStudentID->Location = System::Drawing::Point(542, 157);
            this->txtStudentID->Name = L"txtStudentID";
            this->txtStudentID->Size = System::Drawing::Size(100, 20);
            this->txtStudentID->TabIndex = 4;
            // 
            // txtUserID
            // 
            this->txtUserID->Location = System::Drawing::Point(542, 177);
            this->txtUserID->Name = L"txtUserID";
            this->txtUserID->Size = System::Drawing::Size(100, 20);
            this->txtUserID->TabIndex = 5;
            // 
            // txtDateOfEnrollment
            // 
            this->txtDateOfEnrollment->Location = System::Drawing::Point(542, 197);
            this->txtDateOfEnrollment->Name = L"txtDateOfEnrollment";
            this->txtDateOfEnrollment->Size = System::Drawing::Size(100, 20);
            this->txtDateOfEnrollment->TabIndex = 6;
            // 
            // txtCourse
            // 
            this->txtCourse->Location = System::Drawing::Point(542, 217);
            this->txtCourse->Name = L"txtCourse";
            this->txtCourse->Size = System::Drawing::Size(100, 20);
            this->txtCourse->TabIndex = 7;
            // 
            // label1
            // 
            this->label1->Location = System::Drawing::Point(452, 157);
            this->label1->Name = L"label1";
            this->label1->Size = System::Drawing::Size(100, 23);
            this->label1->TabIndex = 8;
            this->label1->Text = L"Student ID:";
            // 
            // label2
            // 
            this->label2->Location = System::Drawing::Point(452, 177);
            this->label2->Name = L"label2";
            this->label2->Size = System::Drawing::Size(100, 23);
            this->label2->TabIndex = 9;
            this->label2->Text = L"User ID:";
            // 
            // label3
            // 
            this->label3->Location = System::Drawing::Point(452, 197);
            this->label3->Name = L"label3";
            this->label3->Size = System::Drawing::Size(100, 23);
            this->label3->TabIndex = 10;
            this->label3->Text = L"Date of Enrollment:";
            // 
            // label4
            // 
            this->label4->Location = System::Drawing::Point(452, 217);
            this->label4->Name = L"label4";
            this->label4->Size = System::Drawing::Size(100, 23);
            this->label4->TabIndex = 11;
            this->label4->Text = L"Course:";
            // 
            // ManageStudentForm
            // 
            this->BackColor = System::Drawing::SystemColors::ActiveCaption;
            this->ClientSize = System::Drawing::Size(1316, 632);
            this->Controls->Add(this->dataGridView1);
            this->Controls->Add(this->btnAdd);
            this->Controls->Add(this->btnEdit);
            this->Controls->Add(this->btnDelete);
            this->Controls->Add(this->txtStudentID);
            this->Controls->Add(this->txtUserID);
            this->Controls->Add(this->txtDateOfEnrollment);
            this->Controls->Add(this->txtCourse);
            this->Controls->Add(this->label1);
            this->Controls->Add(this->label2);
            this->Controls->Add(this->label3);
            this->Controls->Add(this->label4);
            this->Name = L"ManageStudentForm";
            this->Text = L"Manage Students";
            this->Load += gcnew System::EventHandler(this, &ManageStudentForm::ManageStudentForm_Load);
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
            this->ResumeLayout(false);
            this->PerformLayout();

        }
#pragma endregion

    private:
        void LoadStudentData()
        {
            try
            {
                sqlConn->Open();
                sqlCmd->CommandText = "SELECT * FROM student";
                sqlCmd->Connection = sqlConn;
                sqlAdapter->SelectCommand = sqlCmd;
                studentTable->Clear();
                sqlAdapter->Fill(studentTable);
                dataGridView1->DataSource = studentTable;
            }
            catch (Exception^ ex)
            {
                MessageBox::Show(ex->Message);
            }
            finally
            {
                sqlConn->Close();
            }
        }

    private:
        void btnAdd_Click(Object^ sender, EventArgs^ e)
        {
            try
            {
                sqlConn->Open();
                sqlCmd->CommandText = "INSERT INTO student (studentID, userID, enrollmentDate, course) VALUES (@studentID, @userID, @enrollmentDate, @course)";
                sqlCmd->Parameters->AddWithValue("@studentID", txtStudentID->Text);
                sqlCmd->Parameters->AddWithValue("@userID", txtUserID->Text);
                sqlCmd->Parameters->AddWithValue("@enrollmentDate", txtDateOfEnrollment->Text);
                sqlCmd->Parameters->AddWithValue("@course", txtCourse->Text);
                sqlCmd->Connection = sqlConn;
                sqlCmd->ExecuteNonQuery();
                MessageBox::Show("Student added successfully.");
                LoadStudentData();
            }
            catch (Exception^ ex)
            {
                MessageBox::Show(ex->Message);
            }
            finally
            {
                sqlConn->Close();
            }
        }

    private:
        void btnEdit_Click(Object^ sender, EventArgs^ e)
        {
            try
            {
                sqlConn->Open();
                sqlCmd->CommandText = "UPDATE student SET userID = @userID, enrollmentDate = @enrollmentDate, course = @course WHERE studentID = @studentID";
                sqlCmd->Parameters->AddWithValue("@studentID", txtStudentID->Text);
                sqlCmd->Parameters->AddWithValue("@userID", txtUserID->Text);
                sqlCmd->Parameters->AddWithValue("@enrollmentDate", txtDateOfEnrollment->Text);
                sqlCmd->Parameters->AddWithValue("@course", txtCourse->Text);
                sqlCmd->Connection = sqlConn;
                sqlCmd->ExecuteNonQuery();
                MessageBox::Show("Student updated successfully.");
                LoadStudentData();
            }
            catch (Exception^ ex)
            {
                MessageBox::Show(ex->Message);
            }
            finally
            {
                sqlConn->Close();
            }
        }

    private:
        void btnDelete_Click(Object^ sender, EventArgs^ e)
        {
            try
            {
                sqlConn->Open();
                sqlCmd->CommandText = "DELETE FROM student WHERE studentID = @studentID";
                sqlCmd->Parameters->AddWithValue("@studentID", txtStudentID->Text);
                sqlCmd->Connection = sqlConn;
                sqlCmd->ExecuteNonQuery();
                MessageBox::Show("Student deleted successfully.");
                LoadStudentData();
            }
            catch (Exception^ ex)
            {
                MessageBox::Show(ex->Message);
            }
            finally
            {
                sqlConn->Close();
            }
        }

    private:
        void dataGridView1_CellContentClick(Object^ sender, DataGridViewCellEventArgs^ e)
        {
            // This event will be triggered when a user selects a student
            // from the DataGridView to populate the text fields.
            int rowIndex = e->RowIndex;
            if (rowIndex >= 0)
            {
                DataGridViewRow^ row = dataGridView1->Rows[rowIndex];
                txtStudentID->Text = row->Cells[0]->Value->ToString();
                txtUserID->Text = row->Cells[1]->Value->ToString();
                txtDateOfEnrollment->Text = row->Cells[2]->Value->ToString();
                txtCourse->Text = row->Cells[3]->Value->ToString();
            }
        }
    private: System::Void ManageStudentForm_Load(System::Object^ sender, System::EventArgs^ e) {
    }
};
}
