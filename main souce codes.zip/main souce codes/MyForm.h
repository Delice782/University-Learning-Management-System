#pragma once

namespace AhesiUni {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;
	using namespace System::IO;
	

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();
		MySqlDataReader^ sqlRd;
	private: System::Windows::Forms::Button^ btnPicture;


	public:
		
		
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

		void clearBoxes() {
			txtDepartment->Text = "";
			txtFirstName->Text = "";
			txtLastName->Text = "";
			txtResidentialAddress->Text = "";
			txtSalary->Text = "";
			pbPicture->ImageLocation = "";

		}
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::TextBox^ txtFirstName;
	private: System::Windows::Forms::TextBox^ txtLastName;
	private: System::Windows::Forms::DateTimePicker^ dtpDateofBirth;
	private: System::Windows::Forms::ComboBox^ txtDepartment;
	private: System::Windows::Forms::DateTimePicker^ dtpHireDate;
	private: System::Windows::Forms::RichTextBox^ txtResidentialAddress;
	private: System::Windows::Forms::TextBox^ txtSalary;
	private: System::Windows::Forms::PictureBox^ pbPicture;








	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Button^ btnSave;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->txtFirstName = (gcnew System::Windows::Forms::TextBox());
			this->txtLastName = (gcnew System::Windows::Forms::TextBox());
			this->dtpDateofBirth = (gcnew System::Windows::Forms::DateTimePicker());
			this->txtDepartment = (gcnew System::Windows::Forms::ComboBox());
			this->dtpHireDate = (gcnew System::Windows::Forms::DateTimePicker());
			this->txtResidentialAddress = (gcnew System::Windows::Forms::RichTextBox());
			this->txtSalary = (gcnew System::Windows::Forms::TextBox());
			this->pbPicture = (gcnew System::Windows::Forms::PictureBox());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->btnSave = (gcnew System::Windows::Forms::Button());
			this->btnPicture = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbPicture))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(80, 52);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(184, 37);
			this->label1->TabIndex = 0;
			this->label1->Text = L"First Name:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(80, 133);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(182, 37);
			this->label2->TabIndex = 0;
			this->label2->Text = L"Last Name:";
			this->label2->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(80, 221);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(184, 37);
			this->label3->TabIndex = 0;
			this->label3->Text = L"First Name:";
			this->label3->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(80, 215);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(204, 37);
			this->label4->TabIndex = 0;
			this->label4->Text = L"Date of Birth:";
			this->label4->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(80, 284);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(193, 37);
			this->label5->TabIndex = 0;
			this->label5->Text = L"Department:";
			this->label5->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(80, 358);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(160, 37);
			this->label6->TabIndex = 0;
			this->label6->Text = L"Hire Date:";
			this->label6->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(80, 434);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(309, 37);
			this->label7->TabIndex = 0;
			this->label7->Text = L"Residential Address:";
			this->label7->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->Location = System::Drawing::Point(63, 523);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(0, 37);
			this->label8->TabIndex = 0;
			this->label8->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(101, 648);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(116, 37);
			this->label9->TabIndex = 0;
			this->label9->Text = L"Salary:";
			this->label9->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// txtFirstName
			// 
			this->txtFirstName->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txtFirstName->Location = System::Drawing::Point(482, 52);
			this->txtFirstName->Name = L"txtFirstName";
			this->txtFirstName->Size = System::Drawing::Size(410, 44);
			this->txtFirstName->TabIndex = 1;
			// 
			// txtLastName
			// 
			this->txtLastName->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txtLastName->Location = System::Drawing::Point(482, 133);
			this->txtLastName->Name = L"txtLastName";
			this->txtLastName->Size = System::Drawing::Size(410, 44);
			this->txtLastName->TabIndex = 1;
			// 
			// dtpDateofBirth
			// 
			this->dtpDateofBirth->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->dtpDateofBirth->Format = System::Windows::Forms::DateTimePickerFormat::Short;
			this->dtpDateofBirth->Location = System::Drawing::Point(482, 215);
			this->dtpDateofBirth->Name = L"dtpDateofBirth";
			this->dtpDateofBirth->Size = System::Drawing::Size(326, 44);
			this->dtpDateofBirth->TabIndex = 2;
			// 
			// txtDepartment
			// 
			this->txtDepartment->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txtDepartment->FormattingEnabled = true;
			this->txtDepartment->Items->AddRange(gcnew cli::array< System::Object^  >(3) {
				L"Department of Comuter Science and Information System",
					L"Department of Economics and Business Administration", L"Department of Engineering"
			});
			this->txtDepartment->Location = System::Drawing::Point(482, 287);
			this->txtDepartment->Name = L"txtDepartment";
			this->txtDepartment->Size = System::Drawing::Size(551, 45);
			this->txtDepartment->TabIndex = 3;
			// 
			// dtpHireDate
			// 
			this->dtpHireDate->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->dtpHireDate->Format = System::Windows::Forms::DateTimePickerFormat::Custom;
			this->dtpHireDate->Location = System::Drawing::Point(482, 358);
			this->dtpHireDate->Name = L"dtpHireDate";
			this->dtpHireDate->Size = System::Drawing::Size(326, 44);
			this->dtpHireDate->TabIndex = 2;
			// 
			// txtResidentialAddress
			// 
			this->txtResidentialAddress->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->txtResidentialAddress->Location = System::Drawing::Point(482, 440);
			this->txtResidentialAddress->Name = L"txtResidentialAddress";
			this->txtResidentialAddress->Size = System::Drawing::Size(557, 160);
			this->txtResidentialAddress->TabIndex = 4;
			this->txtResidentialAddress->Text = L"";
			// 
			// txtSalary
			// 
			this->txtSalary->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txtSalary->Location = System::Drawing::Point(482, 648);
			this->txtSalary->Name = L"txtSalary";
			this->txtSalary->Size = System::Drawing::Size(326, 44);
			this->txtSalary->TabIndex = 1;
			// 
			// pbPicture
			// 
			this->pbPicture->BackColor = System::Drawing::Color::Red;
			this->pbPicture->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->pbPicture->Location = System::Drawing::Point(1219, 34);
			this->pbPicture->Name = L"pbPicture";
			this->pbPicture->Size = System::Drawing::Size(400, 399);
			this->pbPicture->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pbPicture->TabIndex = 5;
			this->pbPicture->TabStop = false;
			// 
			// dataGridView1
			// 
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(108, 810);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersWidth = 82;
			this->dataGridView1->RowTemplate->Height = 33;
			this->dataGridView1->Size = System::Drawing::Size(1506, 261);
			this->dataGridView1->TabIndex = 6;
			// 
			// btnSave
			// 
			this->btnSave->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnSave->Location = System::Drawing::Point(482, 711);
			this->btnSave->Name = L"btnSave";
			this->btnSave->Size = System::Drawing::Size(233, 82);
			this->btnSave->TabIndex = 7;
			this->btnSave->Text = L"Save";
			this->btnSave->UseVisualStyleBackColor = true;
			this->btnSave->Click += gcnew System::EventHandler(this, &MyForm::btnSave_Click);
			// 
			// btnPicture
			// 
			this->btnPicture->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnPicture->Location = System::Drawing::Point(1221, 440);
			this->btnPicture->Name = L"btnPicture";
			this->btnPicture->Size = System::Drawing::Size(395, 94);
			this->btnPicture->TabIndex = 8;
			this->btnPicture->Text = L"Upload Picture";
			this->btnPicture->UseVisualStyleBackColor = true;
			this->btnPicture->Click += gcnew System::EventHandler(this, &MyForm::btnPicture_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(12, 25);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->AutoSize = true;
			this->ClientSize = System::Drawing::Size(1834, 1118);
			this->Controls->Add(this->btnPicture);
			this->Controls->Add(this->btnSave);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->pbPicture);
			this->Controls->Add(this->txtResidentialAddress);
			this->Controls->Add(this->txtDepartment);
			this->Controls->Add(this->dtpHireDate);
			this->Controls->Add(this->dtpDateofBirth);
			this->Controls->Add(this->txtSalary);
			this->Controls->Add(this->txtLastName);
			this->Controls->Add(this->txtFirstName);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"MyForm";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Ashesi";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbPicture))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
		sqlConn->ConnectionString = "datasource = localhost; port=3306;"
			"username=root; password=""; database=ashesi";
		sqlConn->Open();
		sqlCmd->Connection = sqlConn;
		sqlCmd->CommandText = "Select * from employee";
		sqlRd = sqlCmd->ExecuteReader();
		sqlDt->Load(sqlRd);
		sqlRd->Close();
		sqlConn->Close();
		dataGridView1->DataSource = sqlDt;
	}
	private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
		
	}
	private: System::Void btnSave_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ firstName = txtFirstName->Text->Trim();
		String^ lastName = txtLastName->Text->Trim();
		DateTime dateOfBirth = dtpDateofBirth->Value;
		String^ department = txtDepartment->Text->Trim();
		DateTime hireDate = dtpHireDate->Value;
		String^ address = txtResidentialAddress->Text->Trim();
		double salary = Convert::ToDouble(txtSalary->Text->Trim());
		array<unsigned char>^ employeePicture;
		String^ fileLocation = pbPicture->ImageLocation;
		try {
			FileStream^ fs = gcnew FileStream(fileLocation, FileMode::Open, FileAccess::Read);
			BinaryReader^ br = gcnew BinaryReader(fs);
			employeePicture = br->ReadBytes(fs->Length);
		}
		catch (Exception^ e) {
			MessageBox::Show("Unable to convert picture to byte stream");
		}

		bool isValid = true;
		if (firstName->Length == 0) {
			MessageBox::Show("Please the first name");
			isValid = false;
		}
		if (lastName->Length == 0) {
			MessageBox::Show("Please enter the last name");
			isValid = false;
		}
		if (department->Length == 0) {
			MessageBox::Show("Please enter the department");
			isValid = false;
		}
		if (address->Length == 0) {
			MessageBox::Show("Please enter the address");
			isValid = false;
		}
		if (salary <= 0) {
			MessageBox::Show("Please salary should be greater 0");
			isValid = false;
		}

		if (isValid) {
			sqlConn->Open();
			sqlCmd->Connection = sqlConn;
			sqlCmd->CommandText = "INSERT INTO employee (FName, LName, DOB, "
				" Department, DateHire, ResAddress, Salary, EmployeeImage) VALUES "
				"(@firstName, @lastName, @dateOfBirth, @department, @hireDate, "
				"@address, @salary, @employeePicture)";
			sqlCmd->Parameters->AddWithValue("@firstName", firstName);
			sqlCmd->Parameters->AddWithValue("@lastName", lastName);
			sqlCmd->Parameters->AddWithValue("@dateOfBirth", dateOfBirth);
			sqlCmd->Parameters->AddWithValue("@department", department);
			sqlCmd->Parameters->AddWithValue("@hireDate", hireDate);
			sqlCmd->Parameters->AddWithValue("@address", address);
			sqlCmd->Parameters->AddWithValue("@salary", salary);
			sqlCmd->Parameters->AddWithValue("@employeePicture", employeePicture);
			try {
				sqlCmd->ExecuteNonQuery();
				sqlCmd->CommandText = "Select * from employee";
				sqlRd = sqlCmd->ExecuteReader();
		        sqlDt->Load(sqlRd);
		        sqlRd->Close();
		        dataGridView1->DataSource = sqlDt;
				sqlConn->Close();
				clearBoxes();
			} 
			catch (Exception^ e) {
				MessageBox::Show("Inserting Data Failed " + e);
				sqlRd->Close();
			}

		}
	}
private: System::Void btnPicture_Click(System::Object^ sender, System::EventArgs^ e) {
	OpenFileDialog^ ofd = gcnew OpenFileDialog();
	ofd->InitialDirectory = "c:\\";
	ofd->Filter = "PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|All Files (*.*)|*.*";
	ofd->FilterIndex = 3;
	ofd->RestoreDirectory = true;
	if (ofd->ShowDialog() == Windows::Forms::DialogResult::OK) {
	   //DialogResult = ofd->ShowDialog();
		pbPicture->ImageLocation = ofd->FileName;
	}
}
};
}
