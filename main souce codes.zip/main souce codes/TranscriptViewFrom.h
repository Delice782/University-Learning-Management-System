#pragma once

namespace FinalProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for TranscriptViewFrom
	/// </summary>
	public ref class TranscriptViewFrom : public System::Windows::Forms::Form
	{
	private:
		// MySQL-related variables
		MySqlConnection^ sqlConn;
		MySqlCommand^ sqlCmd;
		String^ connectionString;
	public:
		TranscriptViewFrom(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			//

			sqlConn = gcnew MySqlConnection();
			sqlCmd = gcnew MySqlCommand();
			connectionString = "server=localhost;user id=root;password=;database=lms;";
			sqlConn->ConnectionString = connectionString;

		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~TranscriptViewFrom()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::ComboBox^ comboBox1;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Button^ button1;


	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(464, 111);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(292, 31);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Transcript View Form";
			this->label1->Click += gcnew System::EventHandler(this, &TranscriptViewFrom::label1_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(557, 228);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(199, 20);
			this->textBox1->TabIndex = 1;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &TranscriptViewFrom::textBox1_TextChanged);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(381, 228);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(61, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Student ID:";
			this->label2->Click += gcnew System::EventHandler(this, &TranscriptViewFrom::label2_Click);
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(557, 273);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(199, 21);
			this->comboBox1->TabIndex = 3;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &TranscriptViewFrom::comboBox1_SelectedIndexChanged);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(381, 281);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(170, 13);
			this->label3->TabIndex = 4;
			this->label3->Text = L"Select Academic Year / Semester:";
			// 
			// dataGridView1
			// 
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(557, 322);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(199, 69);
			this->dataGridView1->TabIndex = 5;
			this->dataGridView1->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &TranscriptViewFrom::dataGridView1_CellContentClick);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(381, 322);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(82, 13);
			this->label4->TabIndex = 6;
			this->label4->Text = L"Courses Taken:";
			this->label4->Click += gcnew System::EventHandler(this, &TranscriptViewFrom::label4_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(610, 420);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(117, 23);
			this->button1->TabIndex = 7;
			this->button1->Text = L"Download Transcript";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &TranscriptViewFrom::button1_Click);
			// 
			// TranscriptViewFrom
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(1423, 765);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label1);
			this->Name = L"TranscriptViewFrom";
			this->Text = L"TranscriptViewFrom";
			this->Load += gcnew System::EventHandler(this, &TranscriptViewFrom::TranscriptViewFrom_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void TranscriptViewFrom_Load(System::Object^ sender, System::EventArgs^ e) {





	}
	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
		String^ studentID = textBox1->Text;

		if (studentID != "") {
			// Open connection only once
			MySqlConnection^ conn = gcnew MySqlConnection(connectionString);
			conn->Open();

			try {
				// Fetch courses for the student
				MySqlCommand^ cmd = gcnew MySqlCommand("SELECT * FROM enrollment WHERE studentID = @studentID", conn);
				cmd->Parameters->AddWithValue("@studentID", studentID);
				MySqlDataReader^ reader = cmd->ExecuteReader();
				DataTable^ dt = gcnew DataTable();
				dt->Load(reader);

				dataGridView1->DataSource = dt;

				// Fetch distinct semesters
				MySqlCommand^ cmdSemesters = gcnew MySqlCommand("SELECT DISTINCT semester FROM enrollment WHERE studentID = @studentID", conn);
				cmdSemesters->Parameters->AddWithValue("@studentID", studentID);
				MySqlDataReader^ semesterReader = cmdSemesters->ExecuteReader();

				comboBox1->Items->Clear(); // Clear previous semesters
				while (semesterReader->Read()) {
					comboBox1->Items->Add(semesterReader->GetString(0));
				}
			}
			catch (Exception^ ex) {
				//MessageBox::Show("Error: " + ex->Message);
			}
			finally {
				conn->Close();
			}
		}
	}
	private: System::Void label4_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
		String^ studentID = textBox1->Text;
		String^ selectedSemester = comboBox1->SelectedItem->ToString();

		if (studentID != "" && selectedSemester != "") {
			// Open connection only once
			MySqlConnection^ conn = gcnew MySqlConnection(connectionString);
			conn->Open();

			try {
				// Fetch courses for the selected semester
				MySqlCommand^ cmd = gcnew MySqlCommand("SELECT c.courseName, e.grade FROM enrollment e JOIN course c ON e.courseID = c.courseID WHERE e.studentID = @studentID AND e.semester = @semester", conn);
				cmd->Parameters->AddWithValue("@studentID", studentID);
				cmd->Parameters->AddWithValue("@semester", selectedSemester);
				MySqlDataReader^ reader = cmd->ExecuteReader();

				// Clear previous results
				dataGridView1->Rows->Clear();
				while (reader->Read()) {
					int rowIndex = dataGridView1->Rows->Add();
					dataGridView1->Rows[rowIndex]->Cells[0]->Value = reader->GetString(0);  // Course Name
					dataGridView1->Rows[rowIndex]->Cells[1]->Value = reader->GetString(1);  // Grade
				}
			}
			catch (Exception^ ex) {
				// MessageBox::Show("Error: " + ex->Message);
			}
			finally {
				conn->Close();
			}
		}
	}
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		// Retrieve the student ID and selected semester from the input fields
		String^ studentID = textBox1->Text;
		String^ selectedSemester = comboBox1->SelectedItem->ToString();

		// Check if both the student ID and selected semester are provided
		if (studentID != "" && selectedSemester != "") {
			// Open a connection to the database using the provided connection string
			MySqlConnection^ conn = gcnew MySqlConnection(connectionString);
			conn->Open();

			try {
				// Create a SQL command to fetch courses and grades for the specified student and semester
				MySqlCommand^ cmd = gcnew MySqlCommand(
					"SELECT c.courseName, e.grade FROM enrollment e JOIN course c ON e.courseID = c.courseID " +
					"WHERE e.studentID = @studentID AND e.semester = @semester", conn);

				// Add parameters to the SQL command to prevent SQL injection
				cmd->Parameters->AddWithValue("@studentID", studentID);
				cmd->Parameters->AddWithValue("@semester", selectedSemester);

				// Execute the command and get a data reader to read the results
				MySqlDataReader^ reader = cmd->ExecuteReader();

				// Clear any previous results from the DataGridView
				dataGridView1->Rows->Clear();

				// Iterate through the results and populate the DataGridView
				while (reader->Read()) {
					// Add a new row to the DataGridView
					int rowIndex = dataGridView1->Rows->Add();

					// Set the course name in the first cell of the new row
					dataGridView1->Rows[rowIndex]->Cells[0]->Value = reader->GetString(0);

					// Set the grade in the second cell of the new row
					dataGridView1->Rows[rowIndex]->Cells[1]->Value = reader->GetString(1);
				}
			}
			catch (Exception^ ex) {
				// Display an error message if an exception occurs
				//MessageBox::Show("Error: " + ex->Message);
			}
			finally {
				// Ensure the database connection is closed regardless of the outcome
				conn->Close();
			}
		}
		else {
			// Display a warning message if the student ID or semester is not provided
			MessageBox::Show("Please enter a valid student ID and select a semester.", "Input Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
		}
	}



	private: System::Void label5_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void dataGridView1_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
		dataGridView1->Columns->Add("Course Name", "Course Name");
		dataGridView1->Columns->Add("Grade", "Grade");

	}
	};
}