#pragma once

namespace FinalProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for UpdateProfileForm
	/// </summary>
	public ref class UpdateProfileForm : public System::Windows::Forms::Form
	{
	private:
		// MySQL-related variables
		MySqlConnection^ sqlConn;
		MySqlCommand^ sqlCmd;
		String^ connectionString;
	public:
		UpdateProfileForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			sqlConn = gcnew MySqlConnection();
			sqlCmd = gcnew MySqlCommand();
			connectionString = "server=localhost;user id=root;password=;database=lms;";
			sqlConn->ConnectionString = connectionString;

		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~UpdateProfileForm()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

		// Declare controls
	private: System::Windows::Forms::TextBox^ firstNameTextBox;
	private: System::Windows::Forms::TextBox^ lastNameTextBox;
	private: System::Windows::Forms::TextBox^ emailTextBox;
	private: System::Windows::Forms::TextBox^ phoneTextBox;
	private: System::Windows::Forms::ComboBox^ departmentComboBox;
	private: System::Windows::Forms::TextBox^ officeLocationTextBox;
	private: System::Windows::Forms::Button^ updateButton;
	private: System::Windows::Forms::Button^ cancelButton;
	private: System::Windows::Forms::PictureBox^ profilePictureBox;

#pragma region Windows Form Designer generated code
		   /// <summary>
		   /// Required method for Designer support - do not modify
		   /// the contents of this method with the code editor.
		   /// </summary>
		   void InitializeComponent(void)
		   {
			   this->firstNameTextBox = (gcnew System::Windows::Forms::TextBox());
			   this->lastNameTextBox = (gcnew System::Windows::Forms::TextBox());
			   this->emailTextBox = (gcnew System::Windows::Forms::TextBox());
			   this->phoneTextBox = (gcnew System::Windows::Forms::TextBox());
			   this->departmentComboBox = (gcnew System::Windows::Forms::ComboBox());
			   this->officeLocationTextBox = (gcnew System::Windows::Forms::TextBox());
			   this->updateButton = (gcnew System::Windows::Forms::Button());
			   this->cancelButton = (gcnew System::Windows::Forms::Button());
			   this->profilePictureBox = (gcnew System::Windows::Forms::PictureBox());
			   (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->profilePictureBox))->BeginInit();
			   this->SuspendLayout();
			   // 
			   // firstNameTextBox
			   // 
			   this->firstNameTextBox->Location = System::Drawing::Point(568, 188);
			   this->firstNameTextBox->Name = L"firstNameTextBox";
			   this->firstNameTextBox->Size = System::Drawing::Size(200, 20);
			   this->firstNameTextBox->TabIndex = 0;
			   // 
			   // lastNameTextBox
			   // 
			   this->lastNameTextBox->Location = System::Drawing::Point(568, 218);
			   this->lastNameTextBox->Name = L"lastNameTextBox";
			   this->lastNameTextBox->Size = System::Drawing::Size(200, 20);
			   this->lastNameTextBox->TabIndex = 1;
			   // 
			   // emailTextBox
			   // 
			   this->emailTextBox->Location = System::Drawing::Point(568, 248);
			   this->emailTextBox->Name = L"emailTextBox";
			   this->emailTextBox->Size = System::Drawing::Size(200, 20);
			   this->emailTextBox->TabIndex = 2;
			   // 
			   // phoneTextBox
			   // 
			   this->phoneTextBox->Location = System::Drawing::Point(568, 278);
			   this->phoneTextBox->Name = L"phoneTextBox";
			   this->phoneTextBox->Size = System::Drawing::Size(200, 20);
			   this->phoneTextBox->TabIndex = 3;
			   // 
			   // departmentComboBox
			   // 
			   this->departmentComboBox->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			   this->departmentComboBox->FormattingEnabled = true;
			   this->departmentComboBox->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"Computer Science", L"Mathematics", L"Physics" });
			   this->departmentComboBox->Location = System::Drawing::Point(568, 308);
			   this->departmentComboBox->Name = L"departmentComboBox";
			   this->departmentComboBox->Size = System::Drawing::Size(200, 21);
			   this->departmentComboBox->TabIndex = 4;
			   // 
			   // officeLocationTextBox
			   // 
			   this->officeLocationTextBox->Location = System::Drawing::Point(568, 338);
			   this->officeLocationTextBox->Name = L"officeLocationTextBox";
			   this->officeLocationTextBox->Size = System::Drawing::Size(200, 20);
			   this->officeLocationTextBox->TabIndex = 5;
			   // 
			   // updateButton
			   // 
			   this->updateButton->Location = System::Drawing::Point(568, 368);
			   this->updateButton->Name = L"updateButton";
			   this->updateButton->Size = System::Drawing::Size(75, 23);
			   this->updateButton->TabIndex = 6;
			   this->updateButton->Text = L"Update";
			   this->updateButton->UseVisualStyleBackColor = true;
			   this->updateButton->Click += gcnew System::EventHandler(this, &UpdateProfileForm::updateButton_Click);
			   // 
			   // cancelButton
			   // 
			   this->cancelButton->Location = System::Drawing::Point(693, 368);
			   this->cancelButton->Name = L"cancelButton";
			   this->cancelButton->Size = System::Drawing::Size(75, 23);
			   this->cancelButton->TabIndex = 7;
			   this->cancelButton->Text = L"Cancel";
			   this->cancelButton->UseVisualStyleBackColor = true;
			   this->cancelButton->Click += gcnew System::EventHandler(this, &UpdateProfileForm::cancelButton_Click);
			   // 
			   // profilePictureBox
			   // 
			   this->profilePictureBox->Location = System::Drawing::Point(433, 188);
			   this->profilePictureBox->Name = L"profilePictureBox";
			   this->profilePictureBox->Size = System::Drawing::Size(100, 100);
			   this->profilePictureBox->TabIndex = 8;
			   this->profilePictureBox->TabStop = false;
			   // 
			   // UpdateProfileForm
			   // 
			   this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			   this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			   this->ClientSize = System::Drawing::Size(1366, 651);
			   this->Controls->Add(this->profilePictureBox);
			   this->Controls->Add(this->cancelButton);
			   this->Controls->Add(this->updateButton);
			   this->Controls->Add(this->officeLocationTextBox);
			   this->Controls->Add(this->departmentComboBox);
			   this->Controls->Add(this->phoneTextBox);
			   this->Controls->Add(this->emailTextBox);
			   this->Controls->Add(this->lastNameTextBox);
			   this->Controls->Add(this->firstNameTextBox);
			   this->Name = L"UpdateProfileForm";
			   this->Text = L"Update Faculty Profile";
			   (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->profilePictureBox))->EndInit();
			   this->ResumeLayout(false);
			   this->PerformLayout();

		   }
#pragma endregion

	private: System::Void updateButton_Click(System::Object^ sender, System::EventArgs^ e) {
		// Update logic here
	}

	private: System::Void cancelButton_Click(System::Object^ sender, System::EventArgs^ e) {
		// Cancel logic here
		this->Close();  // Close the form
	}
	};
}
