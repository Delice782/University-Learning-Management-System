#pragma once

namespace FinalProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for ViewGradeForm
	/// </summary>
	public ref class ViewGradeForm : public System::Windows::Forms::Form
	{
	private:
		// MySQL-related variables
		MySqlConnection^ sqlConn;
		MySqlCommand^ sqlCmd;
		String^ connectionString;

		// Declare DataGridView control
		System::Windows::Forms::DataGridView^ gradesDataGridView;

	public:
		ViewGradeForm(void)
		{
			InitializeComponent();
			sqlConn = gcnew MySqlConnection();
			sqlCmd = gcnew MySqlCommand();
			connectionString = "server=localhost;user id=root;password=;database=lms;";
			sqlConn->ConnectionString = connectionString;

			// Initialize DataGridView
			gradesDataGridView = gcnew System::Windows::Forms::DataGridView();
			gradesDataGridView->Location = System::Drawing::Point(50, 50);  // Adjust location as needed
			gradesDataGridView->Size = System::Drawing::Size(400, 200);    // Adjust size as needed
			this->Controls->Add(gradesDataGridView);  // Add DataGridView to the form
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~ViewGradeForm()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

		// Declare buttons
	private: System::Windows::Forms::Button^ viewGradesButton;
	private: System::Windows::Forms::Button^ closeButton;

#pragma region Windows Form Designer generated code
		   /// <summary>
		   /// Required method for Designer support - do not modify
		   /// the contents of this method with the code editor.
		   /// </summary>
		   void InitializeComponent(void)
		   {
			   this->viewGradesButton = (gcnew System::Windows::Forms::Button());
			   this->closeButton = (gcnew System::Windows::Forms::Button());
			   this->SuspendLayout();
			   // 
			   // viewGradesButton
			   // 
			   this->viewGradesButton->Location = System::Drawing::Point(547, 280);
			   this->viewGradesButton->Name = L"viewGradesButton";
			   this->viewGradesButton->Size = System::Drawing::Size(200, 50);
			   this->viewGradesButton->TabIndex = 0;
			   this->viewGradesButton->Text = L"View Grades";
			   this->viewGradesButton->UseVisualStyleBackColor = true;
			   this->viewGradesButton->Click += gcnew System::EventHandler(this, &ViewGradeForm::viewGradesButton_Click);
			   // 
			   // closeButton
			   // 
			   this->closeButton->Location = System::Drawing::Point(547, 336);
			   this->closeButton->Name = L"closeButton";
			   this->closeButton->Size = System::Drawing::Size(200, 50);
			   this->closeButton->TabIndex = 1;
			   this->closeButton->Text = L"Close";
			   this->closeButton->UseVisualStyleBackColor = true;
			   this->closeButton->Click += gcnew System::EventHandler(this, &ViewGradeForm::closeButton_Click);
			   // 
			   // ViewGradeForm
			   // 
			   this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			   this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			   this->ClientSize = System::Drawing::Size(1336, 646);
			   this->Controls->Add(this->viewGradesButton);
			   this->Controls->Add(this->closeButton);
			   this->Name = L"ViewGradeForm";
			   this->Text = L"View Grade Form";
			   this->Load += gcnew System::EventHandler(this, &ViewGradeForm::ViewGradeForm_Load);
			   this->ResumeLayout(false);

		   }
#pragma endregion

		   // Event handler for 'View Grades' button click
	private: System::Void viewGradesButton_Click(System::Object^ sender, System::EventArgs^ e) {
		// Create a connection to the database
		String^ connectionString = L"datasource=localhost;port=3306;username=root;password=;database=lms;";
		MySqlConnection^ conn = gcnew MySqlConnection(connectionString);

		try {
			// Open the connection
			conn->Open();

			// Modified query to include correct student grades from the Enrollment table
			String^ query = "SELECT c.courseName, e.semester, e.grade "
				"FROM Enrollment e "
				"JOIN Course c ON e.courseID = c.courseID "
				"JOIN Student s ON e.studentID = s.studentID "
				"WHERE s.studentID = @studentID";  // Ensure studentID is passed dynamically

			// Create a command to execute the query
			MySqlCommand^ cmd = gcnew MySqlCommand(query, conn);

			// Assuming you have the current logged-in studentID available
			// You need to pass the actual logged-in studentID, here it's hardcoded for now
			int studentID = 1; // Replace this with actual studentID based on the user
			cmd->Parameters->AddWithValue("@studentID", studentID);

			// Execute the query and get the data in a reader
			MySqlDataReader^ reader = cmd->ExecuteReader();

			// Prepare a DataTable to hold the result
			DataTable^ dataTable = gcnew DataTable();
			dataTable->Load(reader);

			// Set the DataSource of DataGridView to display the grades
			gradesDataGridView->DataSource = dataTable;

			// Close the reader
			reader->Close();
		}
		catch (Exception^ ex) {
			// Show an error message in case of an exception
			MessageBox::Show("Error: " + ex->Message);
		}
		finally {
			// Ensure the connection is closed
			conn->Close();
		}
	}


		   // Event handler for 'Close' button click
	private: System::Void closeButton_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Close();
	}

		   // Event handler for form load
	private: System::Void ViewGradeForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	};
}
