DROP DATABASE IF EXISTS lmsdb;
CREATE DATABASE lmsdb;
USE lmsdb;

CREATE TABLE User (
    userID INT PRIMARY KEY AUTO_INCREMENT,
    firstName VARCHAR(100),
    lastName VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(100)
);

CREATE TABLE Student (
    studentID INT PRIMARY KEY AUTO_INCREMENT,
    userID INT,
    dob DATE,
    picture LONGBLOB,
    major VARCHAR(100),
    enrollmentDate DATE,
    FOREIGN KEY (userID) REFERENCES User(userID)
);

CREATE TABLE Faculty (
    facultyID INT PRIMARY KEY AUTO_INCREMENT,
    userID INT,
    date_of_appointment DATE,
    department VARCHAR(100),
    FOREIGN KEY (userID) REFERENCES User(userID)
);

CREATE TABLE Course (
    courseID INT PRIMARY KEY AUTO_INCREMENT,
    courseName VARCHAR(100),
    credits INT,
    schedule VARCHAR(50)
);

CREATE TABLE Enrollment (
    enrollmentID INT PRIMARY KEY AUTO_INCREMENT,
    studentID INT,
    courseID INT,
    semester VARCHAR(50),
    grade VARCHAR(10),
    FOREIGN KEY (studentID) REFERENCES Student(studentID),
    FOREIGN KEY (courseID) REFERENCES Course(courseID)
);
