#pragma once

namespace FinalProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace System::Data::SqlClient;

    /// <summary>
    /// Summary for payFeesForm
    /// </summary>
    public ref class payFeesForm : public System::Windows::Forms::Form
    {
    public:
        payFeesForm(void)
        {
            InitializeComponent();
        }

    protected:
        ~payFeesForm()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container^ components;

    private: System::Windows::Forms::Label^ labelOutstandingFees;
    private: System::Windows::Forms::TextBox^ textBoxAmountToPay;
    private: System::Windows::Forms::Button^ buttonSubmitPayment;
    private: System::Windows::Forms::Label^ label1;
    private: System::Windows::Forms::TextBox^ textBox1;
    private: System::Windows::Forms::TextBox^ textBox2;
    private: System::Windows::Forms::Label^ label2;
    private: System::Windows::Forms::Button^ buttonClose;

#pragma region Windows Form Designer generated code
           void InitializeComponent(void)
           {
               this->labelOutstandingFees = (gcnew System::Windows::Forms::Label());
               this->textBoxAmountToPay = (gcnew System::Windows::Forms::TextBox());
               this->buttonSubmitPayment = (gcnew System::Windows::Forms::Button());
               this->buttonClose = (gcnew System::Windows::Forms::Button());
               this->label1 = (gcnew System::Windows::Forms::Label());
               this->textBox1 = (gcnew System::Windows::Forms::TextBox());
               this->textBox2 = (gcnew System::Windows::Forms::TextBox());
               this->label2 = (gcnew System::Windows::Forms::Label());
               this->SuspendLayout();

               // labelOutstandingFees
               this->labelOutstandingFees->AutoSize = true;
               this->labelOutstandingFees->Location = System::Drawing::Point(558, 171);
               this->labelOutstandingFees->Name = L"labelOutstandingFees";
               this->labelOutstandingFees->Size = System::Drawing::Size(75, 13);
               this->labelOutstandingFees->TabIndex = 0;
               this->labelOutstandingFees->Text = L"Student Name";

               // textBoxAmountToPay
               this->textBoxAmountToPay->Location = System::Drawing::Point(668, 212);
               this->textBoxAmountToPay->Name = L"textBoxAmountToPay";
               this->textBoxAmountToPay->Size = System::Drawing::Size(120, 20);
               this->textBoxAmountToPay->TabIndex = 3;

               // buttonSubmitPayment
               this->buttonSubmitPayment->Location = System::Drawing::Point(668, 306);
               this->buttonSubmitPayment->Name = L"buttonSubmitPayment";
               this->buttonSubmitPayment->Size = System::Drawing::Size(120, 23);
               this->buttonSubmitPayment->TabIndex = 4;
               this->buttonSubmitPayment->Text = L"Submit Payment";
               this->buttonSubmitPayment->UseVisualStyleBackColor = true;
               this->buttonSubmitPayment->Click += gcnew System::EventHandler(this, &payFeesForm::buttonSubmitPayment_Click);

               // buttonClose
               this->buttonClose->Location = System::Drawing::Point(623, 352);
               this->buttonClose->Name = L"buttonClose";
               this->buttonClose->Size = System::Drawing::Size(110, 23);
               this->buttonClose->TabIndex = 6;
               this->buttonClose->Text = L"Close";
               this->buttonClose->UseVisualStyleBackColor = true;
               this->buttonClose->Click += gcnew System::EventHandler(this, &payFeesForm::buttonClose_Click);

               // label1
               this->label1->AutoSize = true;
               this->label1->Location = System::Drawing::Point(558, 219);
               this->label1->Name = L"label1";
               this->label1->Size = System::Drawing::Size(55, 13);
               this->label1->TabIndex = 7;
               this->label1->Text = L"StudentID";

               // textBox1
               this->textBox1->Location = System::Drawing::Point(668, 164);
               this->textBox1->Name = L"textBox1";
               this->textBox1->Size = System::Drawing::Size(120, 20);
               this->textBox1->TabIndex = 8;

               // textBox2
               this->textBox2->Location = System::Drawing::Point(668, 260);
               this->textBox2->Name = L"textBox2";
               this->textBox2->Size = System::Drawing::Size(120, 20);
               this->textBox2->TabIndex = 9;

               // label2
               this->label2->AutoSize = true;
               this->label2->Location = System::Drawing::Point(558, 267);
               this->label2->Name = L"label2";
               this->label2->Size = System::Drawing::Size(79, 13);
               this->label2->TabIndex = 10;
               this->label2->Text = L"Amount to Pay:";

               // payFeesForm
               this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
               this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
               this->BackColor = System::Drawing::SystemColors::ActiveCaption;
               this->ClientSize = System::Drawing::Size(1263, 566);
               this->Controls->Add(this->label2);
               this->Controls->Add(this->textBox2);
               this->Controls->Add(this->textBox1);
               this->Controls->Add(this->label1);
               this->Controls->Add(this->buttonClose);
               this->Controls->Add(this->buttonSubmitPayment);
               this->Controls->Add(this->textBoxAmountToPay);
               this->Controls->Add(this->labelOutstandingFees);
               this->Name = L"payFeesForm";
               this->Text = L"Pay Fees";
               this->ResumeLayout(false);
               this->PerformLayout();
           }
#pragma endregion

    private: System::Void buttonSubmitPayment_Click(System::Object^ sender, System::EventArgs^ e) {
        try {
            String^ studentID = textBox1->Text;
            String^ paymentAmountText = textBox2->Text;
            double paymentAmount;

            if (!Double::TryParse(paymentAmountText, paymentAmount)) {
                MessageBox::Show("Invalid payment amount.");
                return;
            }

            String^ connectionString = "your_connection_string_here";
            String^ query = "UPDATE student SET AmountPaid = AmountPaid + @AmountToPay WHERE studentID = @StudentID";

            SqlConnection^ connection = gcnew SqlConnection(connectionString);
            SqlCommand^ command = gcnew SqlCommand(query, connection);

            command->Parameters->AddWithValue("@AmountToPay", paymentAmount);
            command->Parameters->AddWithValue("@StudentID", studentID);

            connection->Open();
            int rowsAffected = command->ExecuteNonQuery();
            connection->Close();

            if (rowsAffected > 0) {
                MessageBox::Show("Payment successfully recorded.");
            }
            else {
                MessageBox::Show("Student ID not found.");
            }
        }
        catch (Exception^ ex) {
            // Use the exception message in the catch block to log the error
            MessageBox::Show("An error occurred: " + ex->Message);
        }
    }

    private: System::Void buttonClose_Click(System::Object^ sender, System::EventArgs^ e) {
        this->Close();
    }
    };
}
