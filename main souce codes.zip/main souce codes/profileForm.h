#pragma once

 // Include this for MySQL connection
namespace FinalProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	public ref class profileForm : public System::Windows::Forms::Form
	{
	public:
		profileForm(void)
		{
			InitializeComponent();
		}

	protected:
		~profileForm()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

		// Labels to display the student information
		System::Windows::Forms::Label^ labelName;
		System::Windows::Forms::Label^ labelStudentID;
		System::Windows::Forms::Label^ labelDepartment;

		// MySQL connection, command, and reader objects
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		MySqlDataReader^ sqlRd;

#pragma region Windows Form Designer generated code
		void InitializeComponent(void)
		{
			this->labelName = (gcnew System::Windows::Forms::Label());
			this->labelStudentID = (gcnew System::Windows::Forms::Label());
			this->labelDepartment = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// labelName
			// 
			this->labelName->AutoSize = true;
			this->labelName->Location = System::Drawing::Point(514, 274);
			this->labelName->Name = L"labelName";
			this->labelName->Size = System::Drawing::Size(60, 13);
			this->labelName->TabIndex = 0;
			this->labelName->Text = L"Full Name: ";
			// 
			// labelStudentID
			// 
			this->labelStudentID->AutoSize = true;
			this->labelStudentID->Location = System::Drawing::Point(514, 304);
			this->labelStudentID->Name = L"labelStudentID";
			this->labelStudentID->Size = System::Drawing::Size(64, 13);
			this->labelStudentID->TabIndex = 1;
			this->labelStudentID->Text = L"Student ID: ";
			// 
			// labelDepartment
			// 
			this->labelDepartment->AutoSize = true;
			this->labelDepartment->Location = System::Drawing::Point(514, 334);
			this->labelDepartment->Name = L"labelDepartment";
			this->labelDepartment->Size = System::Drawing::Size(68, 13);
			this->labelDepartment->TabIndex = 2;
			this->labelDepartment->Text = L"Department: ";
			// 
			// profileForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(1349, 655);
			this->Controls->Add(this->labelDepartment);
			this->Controls->Add(this->labelStudentID);
			this->Controls->Add(this->labelName);
			this->Name = L"profileForm";
			this->Text = L"Profile Form";
			this->Load += gcnew System::EventHandler(this, &profileForm::profileForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

		// On form load, connect to database and retrieve the data
		System::Void profileForm_Load(System::Object^ sender, System::EventArgs^ e)
		{
			try
			{
				// Establish MySQL connection
				sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=lms";
				sqlConn->Open();

				// SQL query to retrieve full name, student ID, and department
				sqlCmd->CommandText = "SELECT CONCAT(U.firstName, ' ', U.lastName) AS Name, "
					"U.userID AS StudentID, F.department "
					"FROM user U "
					"INNER JOIN enrollment E ON U.userID = E.studentID "
					"INNER JOIN faculty F ON E.studentID = F.userID "
					"WHERE U.userID = 2";  

				// Assign connection for the query
				sqlCmd->Connection = sqlConn;

				// Execute the query and get the data
				sqlRd = sqlCmd->ExecuteReader();

				// If data is returned, display it
				if (sqlRd->Read())
				{
					labelName->Text = "Full Name: " + sqlRd["Name"]->ToString();
					labelStudentID->Text = "Student ID: " + sqlRd["StudentID"]->ToString();
					labelDepartment->Text = "Department: " + sqlRd["department"]->ToString();
				}
				else
				{
					MessageBox::Show("No data found for the given user.");
				}

				// Close the data reader
				sqlRd->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show("Error: " + ex->Message);
			}
			finally
			{
				// Close the MySQL connection
				sqlConn->Close();
			}
		}
	};
}
