#pragma once

namespace FinalProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for viewRosterForm
	/// </summary>
	public ref class viewRosterForm : public System::Windows::Forms::Form
	{
	private:
		// MySQL-related variables
		MySqlConnection^ sqlConn;
		MySqlCommand^ sqlCmd;
		String^ connectionString;

	public:
		viewRosterForm(void)
		{
			InitializeComponent();
			//
			// MySQL connection setup
			sqlConn = gcnew MySqlConnection();
			sqlCmd = gcnew MySqlCommand();
			connectionString = "server=localhost;user id=root;password=;database=lms;";
			sqlConn->ConnectionString = connectionString;
		}

	protected:
		~viewRosterForm()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::ListView^ listViewRoster;

	private:
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		void InitializeComponent(void)
		{
			this->listViewRoster = (gcnew System::Windows::Forms::ListView());
			this->SuspendLayout();
			// 
			// listViewRoster
			// 
			this->listViewRoster->HideSelection = false;
			this->listViewRoster->Location = System::Drawing::Point(12, 12);
			this->listViewRoster->Name = L"listViewRoster";
			this->listViewRoster->Size = System::Drawing::Size(396, 200);
			this->listViewRoster->TabIndex = 0;
			this->listViewRoster->UseCompatibleStateImageBehavior = false;
			this->listViewRoster->View = System::Windows::Forms::View::Details;

			// Define columns
			this->listViewRoster->Columns->Add("Student ID", 100, HorizontalAlignment::Left);
			this->listViewRoster->Columns->Add("Student Name", 250, HorizontalAlignment::Left);

			this->listViewRoster->SelectedIndexChanged += gcnew System::EventHandler(this, &viewRosterForm::listViewRoster_SelectedIndexChanged);
			// 
			// viewRosterForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(420, 230);
			this->Controls->Add(this->listViewRoster);
			this->Name = L"viewRosterForm";
			this->Text = L"Class Roster";
			this->Load += gcnew System::EventHandler(this, &viewRosterForm::viewRosterForm_Load);
			this->ResumeLayout(false);

		}
#pragma endregion
	private:
		System::Void viewRosterForm_Load(System::Object^ sender, System::EventArgs^ e) {
			try {
				sqlConn->Open();
				sqlCmd->Connection = sqlConn;
				// Correct SQL Query
				sqlCmd->CommandText = "SELECT student.studentID, CONCAT(user.firstName, ' ', user.lastName) AS student_name "
					"FROM student "
					"INNER JOIN user ON student.userID = user.userID "
					"WHERE user.role = 'student'";

				MySqlDataReader^ reader = sqlCmd->ExecuteReader();

				// Populate ListView
				while (reader->Read()) {
					// Create ListViewItem with Student ID
					ListViewItem^ item = gcnew ListViewItem(reader["studentID"]->ToString());
					// Add Student Name as SubItem
					item->SubItems->Add(reader["student_name"]->ToString());
					listViewRoster->Items->Add(item);
				}
				reader->Close();
				sqlConn->Close();
			}
			catch (Exception^ ex) {
				MessageBox::Show("Error: " + ex->Message, "Database Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			}
		}

	private: System::Void listViewRoster_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	};
}