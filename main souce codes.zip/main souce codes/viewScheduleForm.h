#pragma once

namespace FinalProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    /// <summary>
    /// Summary for viewScheduleForm
    /// </summary>
    public ref class viewScheduleForm : public System::Windows::Forms::Form
    {
    public:
        viewScheduleForm(void)
        {
            InitializeComponent();
            //
            //TODO: Add the constructor code here
            //
        }

    protected:
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        ~viewScheduleForm()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        /// <summary>
        /// Required designer variable.
        /// </summary>
        System::ComponentModel::Container^ components;

        // Define UI Components
    private: System::Windows::Forms::Label^ labelScheduleTitle;
    private: System::Windows::Forms::ListBox^ listBoxSchedule;
    private: System::Windows::Forms::Button^ buttonRefresh;
    private: System::Windows::Forms::Button^ buttonPrint;
    private: System::Windows::Forms::Button^ buttonClose;

#pragma region Windows Form Designer generated code
           /// <summary>
           /// Required method for Designer support - do not modify
           /// the contents of this method with the code editor.
           /// </summary>
           void InitializeComponent(void)
           {
               this->labelScheduleTitle = (gcnew System::Windows::Forms::Label());
               this->listBoxSchedule = (gcnew System::Windows::Forms::ListBox());
               this->buttonRefresh = (gcnew System::Windows::Forms::Button());
               this->buttonPrint = (gcnew System::Windows::Forms::Button());
               this->buttonClose = (gcnew System::Windows::Forms::Button());
               this->SuspendLayout();
               // 
               // labelScheduleTitle
               // 
               this->labelScheduleTitle->AutoSize = true;
               this->labelScheduleTitle->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Bold));
               this->labelScheduleTitle->Location = System::Drawing::Point(559, 203);
               this->labelScheduleTitle->Name = L"labelScheduleTitle";
               this->labelScheduleTitle->Size = System::Drawing::Size(136, 17);
               this->labelScheduleTitle->TabIndex = 0;
               this->labelScheduleTitle->Text = L"Student Schedule";
               // 
               // listBoxSchedule
               // 
               this->listBoxSchedule->FormattingEnabled = true;
               this->listBoxSchedule->Location = System::Drawing::Point(559, 233);
               this->listBoxSchedule->Name = L"listBoxSchedule";
               this->listBoxSchedule->Size = System::Drawing::Size(240, 134);
               this->listBoxSchedule->TabIndex = 1;
               // 
               // buttonRefresh
               // 
               this->buttonRefresh->Location = System::Drawing::Point(559, 383);
               this->buttonRefresh->Name = L"buttonRefresh";
               this->buttonRefresh->Size = System::Drawing::Size(75, 23);
               this->buttonRefresh->TabIndex = 2;
               this->buttonRefresh->Text = L"Refresh";
               this->buttonRefresh->UseVisualStyleBackColor = true;
               this->buttonRefresh->Click += gcnew System::EventHandler(this, &viewScheduleForm::buttonRefresh_Click);
               // 
               // buttonPrint
               // 
               this->buttonPrint->Location = System::Drawing::Point(644, 383);
               this->buttonPrint->Name = L"buttonPrint";
               this->buttonPrint->Size = System::Drawing::Size(75, 23);
               this->buttonPrint->TabIndex = 3;
               this->buttonPrint->Text = L"Print";
               this->buttonPrint->UseVisualStyleBackColor = true;
               this->buttonPrint->Click += gcnew System::EventHandler(this, &viewScheduleForm::buttonPrint_Click);
               // 
               // buttonClose
               // 
               this->buttonClose->Location = System::Drawing::Point(729, 383);
               this->buttonClose->Name = L"buttonClose";
               this->buttonClose->Size = System::Drawing::Size(75, 23);
               this->buttonClose->TabIndex = 4;
               this->buttonClose->Text = L"Close";
               this->buttonClose->UseVisualStyleBackColor = true;
               this->buttonClose->Click += gcnew System::EventHandler(this, &viewScheduleForm::buttonClose_Click);
               // 
               // viewScheduleForm
               // 
               this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
               this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
               this->BackColor = System::Drawing::SystemColors::ActiveCaption;
               this->ClientSize = System::Drawing::Size(1335, 640);
               this->Controls->Add(this->buttonClose);
               this->Controls->Add(this->buttonPrint);
               this->Controls->Add(this->buttonRefresh);
               this->Controls->Add(this->listBoxSchedule);
               this->Controls->Add(this->labelScheduleTitle);
               this->Name = L"viewScheduleForm";
               this->Text = L"View Schedule";
               this->Load += gcnew System::EventHandler(this, &viewScheduleForm::viewScheduleForm_Load);
               this->ResumeLayout(false);
               this->PerformLayout();

           }
#pragma endregion

    private: System::Void viewScheduleForm_Load(System::Object^ sender, System::EventArgs^ e) {
        // Load the schedule from database or other sources.
        LoadSchedule();
    }

    private: System::Void LoadSchedule() {
        // Placeholder: Add logic to load schedule data.
        listBoxSchedule->Items->Clear();
        listBoxSchedule->Items->Add(L"Monday: Math at 10 AM");
        listBoxSchedule->Items->Add(L"Tuesday: Science at 11 AM");
        listBoxSchedule->Items->Add(L"Wednesday: History at 1 PM");
    }

    private: System::Void buttonRefresh_Click(System::Object^ sender, System::EventArgs^ e) {
        // Refresh the schedule.
        LoadSchedule();
    }

    private: System::Void buttonPrint_Click(System::Object^ sender, System::EventArgs^ e) {
        // Add logic to print the schedule.
        MessageBox::Show(L"Schedule printed successfully!", L"Print", MessageBoxButtons::OK, MessageBoxIcon::Information);
    }

    private: System::Void buttonClose_Click(System::Object^ sender, System::EventArgs^ e) {
        this->Close(); // Close the form.
    }
    };
}
